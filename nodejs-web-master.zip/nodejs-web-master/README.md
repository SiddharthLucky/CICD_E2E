# Nodejs Web

# This Project Contains Two Folders.

1. Build
2. Terraform

## Architecture:

![blank diagram - copy 1.JPG](Nodejs-Image/Architect.jpg)

## Build:

1. It contains web and api code
2. To Test in local and see the changes use below commands

   ```bash
   docker-compose up -d #to start the application in your local for testing
   docker-compose down  #to shutdown the application
   ```

## Terraform:

## Setup:

- state:
  - Should Execute this only once before creation of project in AWS using terraform
  - This stores all your tfstate files and locking mechanism for the terraform to execute.
    ```bash
    terraform init
    terraform plan
    terraform apply -auto-approve
    ```
  - once its setup and s3 is built move on to the next folder in setup vpc.
- VPC:
  - It contains setting about network and creating ecr repo for this project
  - once executed above commands you should see that network setup is done and its state file is stored in the bucket you have selected to create in state step.
  - change the account in variables.tf
    ```bash
    terraform init
    terraform plan
    terraform apply -auto-approve
    ```

## Pre:

- pre
  - This contains setting for alb,sg,cdn,rds.
  - To execute this code using terraform one should export the environment variable.
    ```bash
    export envrionment=prod #can choose any dev,test,stage accordingly
    terraform init
    echo "`terraform plan -vars-file=./vars/${environment}.tfvars`"
    echo "`terraform apply -vars-file=./vars/${environment}.tfvars`"
    ```

## Deploy:

- deploy:
  - This contains autoscale,ecs,targetgroups,iam,sg,logs
  - To exectue this code using terraform one should export the environment variable
    ```bash
    export envrionment=prod #can choose any dev,test,stage accordingly
    terraform init
    echo "`terraform plan -vars-file=./vars/${environment}.tfvars`"
    echo "`terraform apply -vars-file=./vars/${environment}.tfvars`"
    ```
